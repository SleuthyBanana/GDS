#!/bin/bash
./gends_run_gen_sa.py -f -v $1
