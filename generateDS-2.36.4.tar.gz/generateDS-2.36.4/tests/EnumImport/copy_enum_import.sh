#!/bin/sh
cp enum_import00.py enum_import00_2.py
cp enum_import01.py enum_import01_2.py
cp enum_import02.py enum_import02_2.py
